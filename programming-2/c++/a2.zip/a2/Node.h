#include "Data.h"
class Node{
    private : 
        Node * _right;
        Node * _left;
        Data * _data;
    public :
        Node(Data* data);
        void setRightNode(Node * right);
        void setLeftNode(Node * left);
        Node * getLeftNode();
        Node * getRightNode();
        Data * getData();
};