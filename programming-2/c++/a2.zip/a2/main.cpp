#include <iostream>
//#include "Data.h"
//#include "Node.h"
#include <vector>
#include <string>
#include "Tree.h"

int main(){
    int n ;
    std :: cin >> n ;
    Tree t ;
    //Taking preorder
    for(int q = 0 ; q < n ; q++){
        std::string name;
        std :: cin >> name;
        Data* d =new  Data(name,q);
        Node *n = new Node(d);
        t.addInPreOrder(n);
    }

    //Taking outorder

    for (int q = 0 ; q < n ; q++){
        int index;
        std::cin >> index;
        t.addInOrder(t.getFromPreOrder(index));
    }

   Node * root =  t.buildTree(0,n-1);
    t.printPostOrder(root);
}
